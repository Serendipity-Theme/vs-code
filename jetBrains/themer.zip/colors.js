// This file can be used with the themer CLI, see https://github.com/mjswensen/themer

module.exports.colors = {
  "dark": {
    "shade0": "#232834",
    "shade7": "#CBCCC6",
    "accent0": "#F06897",
    "accent1": "#BE95FF",
    "accent2": "#FAD07B",
    "accent3": "#A6CC70",
    "accent4": "#90E1C6",
    "accent5": "#6DCBFA",
    "accent6": "#F06897",
    "accent7": "#CFBAFA"
  }
};

// Your theme's URL: https://themer.dev/?colors.dark.accent0=%23F06897&colors.dark.accent1=%23be95ff&colors.dark.accent2=%23fad07b&colors.dark.accent3=%23a6cc70&colors.dark.accent4=%2390e1c6&colors.dark.accent5=%236dcbfa&colors.dark.accent6=%23F06897&colors.dark.accent7=%23cfbafa&colors.dark.shade0=%23232834&colors.dark.shade7=%23cbccc6&activeColorSet=dark&calculateIntermediaryShades.dark=true&calculateIntermediaryShades.light=true
